<?php
session_start();
include("templates/header.php");
?>

<br>
<div class="p-5 mb-4 bg-light rounded-3">
    <div class="container-fluid py-5 text-center">
        <h1 class="display-5 fw-bold text-primary">BIENVENIDO</h1>
        
        <div class="row justify-content-center mt-4">
            <div class="col-md-6">
                <div class="card shadow-sm border-0">
                    <div class="card-body">
                        <div class="user-info text-start">
                            <p class="fs-5 mb-3">
                                <span class="badge bg-primary me-2"></span>
                                <strong>Usuario:</strong> <?php echo $_SESSION['usuario']; ?>
                            </p>
                            <p class="fs-5 mb-3">
                                <span class="badge bg-secondary me-2"></span>
                                <strong>UsuarioID:</strong> <?php echo $_SESSION['usuario_id']; ?>
                            </p>
                            <p class="fs-5 mb-3">
                                <span class="badge bg-info me-2"></span>
                                <strong>Email:</strong> <?php echo $_SESSION['email']; ?>
                            </p>
                            <p class="fs-5 mb-3">
                                <span class="badge bg-warning me-2"></span>
                                <strong>Role:</strong> <?php echo $_SESSION['role']; ?>
                            </p>
                            <p class="fs-5 mb-3">
                                <span class="badge bg-success me-2"></span>
                                <strong>Logueado:</strong> <?php echo $_SESSION['usuario_id']; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-4">
            <button class="btn btn-primary btn-lg px-4" type="button">
             Comenzar
            </button>
        </div>
    </div>
</div>

<?php
include("templates/footer.php");
?>