<?php
$servidor = "localhost"; //127.0.0.1
$baseDeDatos = "bike_store";
$usuario = "root";
$contrasenia = "";

try {
    $conexion = new PDO("mysql:host=$servidor;dbname=$baseDeDatos", $usuario, $contrasenia);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Conexión exitosa";
} catch (Exception $ex) {
    echo "Error: " . $ex->getMessage();
}
?>