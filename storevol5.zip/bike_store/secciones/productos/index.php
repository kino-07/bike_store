<?php

include("../../bd.php");
//envio de parametros en la url en el metodo get
if (isset($_GET['txtID'])){
    $txtID=(isset($_GET['txtID']))?$_GET['txtID']:"";
    //BUSCAR EL ARCHIVO RELACIONADO CON EL CLIENTE 
    $sentencia=$conexion->prepare("SELECT foto FROM products WHERE product_id=:id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia-> execute();
    $registro_recuperado=$sentencia->fetch(PDO::FETCH_LAZY);//se utiliza el fetch lazy cuando es solo un dato

    // buscar el arcgibo y eliminar

    if(isset($registro_recuperado['foto']) && $registro_recuperado['foto']!=""){
        if(file_exists("./foto/".$registro_recuperado['foto'])){
            unlink("./foto/".$registro_recuperado['foto']);
        }
    }


    //borra los datos del cliente

    $sentencia=$conexion->prepare("DELETE FROM products WHERE product_id =:id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();
    $mensaje="REGISTRO ELIMINADO";
}

//consulta paar traer los clientes y mostrar como unico regisro 
$sentencia = $conexion-> prepare("SELECT * FROM products"); //el que idce cosytumer el para la tabla asi como usuario asia si 
$sentencia -> execute();
$lista_clientes =  $sentencia-> fetchAll( PDO :: FETCH_ASSOC);
//print_r('$lista_clientes');

?>
<?php
include("../../templates/header.php");
?>



<h2>Lista de Productos</h2>

<!--bs5-card-bead-fut para agregar lo de abajo-->
<div class="card">
    <div class="card-header"><a class="btn btn-outline-primary" href="crear.php" role="button">Nuevo Producto</a></div>
    <div class="card-body">
        <div
            class="table-responsive-sm"
        >
            <table
                class="table table-primary" id="Table_id"
            >
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">PRODUCTO</th>
                        <th scope="col">FOTO</th>
                        <th scope="col">MODELO</th>
                        <th scope="col">PRECIO</th>
                        <th scope="col">CATEGORIA</th>
                        <th scope="col">ACCIONES</th>
                        <th></th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($lista_clientes as $registro) {?>
                    <tr class="">
                        <td scope="row"> <?php echo $registro ['product_id'] ?> </td>
                        <td>
                            <?php echo $registro ['product_name']; ?>
                        </td>
                        <td><img width="100" src="./foto//<?php echo $registro ['foto'];?>"
                        class="img-fluid rounded" alt="foto del cliente" /> </td>
                        <td><?php echo $registro ['model_year']; ?></td>
                        <td><?php echo $registro ['price']; ?></td>
                        <td><?php echo $registro ['category_id']; ?></td>
                        <td> <a class="btn btn-outline-primary" href="editar.php?txtID=<?php echo $registro ['product_id']; ?>"role = "button">Editar </a></td>
                        <td> <a class="btn btn-outline-danger" href="index.php?txtID=<?php echo $registro ['product_id']; ?>"role = "button">Eliminar </a></td>
                    </tr>
                    <?php }?>
                </tbody>
            </table>
        </div>
        

    </div>

<?php
include("../../templates/footer.php");
?>



