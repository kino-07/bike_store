<?php include("../../bd.php");

// Obtener todas las categorías para el select
$sentencia_categorias = $conexion->prepare("SELECT * FROM categories");
$sentencia_categorias->execute();
$categorias = $sentencia_categorias->fetchAll(PDO::FETCH_ASSOC);

if (isset($_GET['txtID'])){
    $txtID=(isset($_GET['txtID']))?$_GET['txtID']:"";
    $sentencia = $conexion->prepare("SELECT * FROM products WHERE product_id = :id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();
    $registro=$sentencia->fetch(PDO::FETCH_LAZY);
    $product_name=$registro["product_name"];
    $foto=$registro["foto"];
    $model_year=$registro["model_year"];
    $price=$registro["price"];
    $category_id=$registro["category_id"];
}

if($_POST){
    $txtID=(isset($_POST['product_id']))?$_POST['product_id']:"";
    $product_name=(isset($_POST['product_name'])?$_POST['product_name']:"");
    $model_year=(isset($_POST['model_year'])?$_POST['model_year']:"");   
    $price=(isset($_POST['price'])?$_POST['price']:"");
    $category_id=(isset($_POST['category_id'])?$_POST['category_id']:"");  
    $foto = (isset($_FILES['foto']['name'])) ? $_FILES['foto']['name'] : "";

    // Procesar la foto primero
    $nombreArchivo_foto = $foto;
    
    if(!empty($foto)) {
        $fecha_=new DateTime();
        $nombreArchivo_foto=$fecha_->getTimestamp()."_".$_FILES['foto']['name'];
        $tmp_foto = $_FILES['foto']['tmp_name'];
        
        if ($tmp_foto!=''){
            move_uploaded_file($tmp_foto,"./foto/".$nombreArchivo_foto);
            
            $sentencia=$conexion->prepare("SELECT foto FROM products WHERE product_id=:id");
            $sentencia->bindParam(":id",$txtID);
            $sentencia->execute();
            $registro_recuperado=$sentencia->fetch(PDO::FETCH_LAZY);
            
            if(isset($registro_recuperado['foto']) && $registro_recuperado['foto']!=""){
                if (file_exists("./foto/".$registro_recuperado['foto'])){
                    unlink("./foto/".$registro_recuperado['foto']);
                }
            }
        }
    } else {
        $sentencia=$conexion->prepare("SELECT foto FROM products WHERE product_id=:id");
        $sentencia->bindParam(":id",$txtID);
        $sentencia->execute();
        $registro_recuperado=$sentencia->fetch(PDO::FETCH_LAZY);
        $nombreArchivo_foto = $registro_recuperado['foto'];
    }

    $sentencia = $conexion->prepare("UPDATE products SET
    product_name= :product_name,
    foto=:foto,
    model_year= :model_year,
    price=:price,
    category_id=:category_id WHERE product_id=:id");

    $sentencia->bindParam(":product_name",$product_name);
    $sentencia->bindParam(":foto",$nombreArchivo_foto);
    $sentencia->bindParam(":model_year",$model_year);
    $sentencia->bindParam(":price",$price);
    $sentencia->bindParam(":category_id",$category_id);
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();

    $mensaje="Registro actualizado correctamente";
    header("Location: index.php?mensaje=".$mensaje);
    exit();
}
?>

<?php include("../../templates/header.php"); ?>

<div class="card shadow-sm">
    <div class="card-header bg-primary text-white py-3">
        <h4 class="mb-0">Editar Producto</h4>
    </div>
    <div class="card-body p-4">
        <form action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="product_id" value="<?php echo $txtID;?>">
            
            <div class="row">
                <!-- Columna Izquierda -->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="product_id" class="form-label fw-bold">ID del Producto</label>
                        <input type="text" value="<?php echo $txtID;?>" class="form-control" readonly name="product_id" id="product_id"/>
                    </div>

                    <div class="mb-3">
                        <label for="product_name" class="form-label fw-bold">Nombre del Producto</label>
                        <input type="text" value="<?php echo $product_name;?>" class="form-control" name="product_name" id="product_name" placeholder="Ingrese el nombre del producto" required/>
                        <div class="form-text text-muted">Actualice el nombre del producto</div>
                    </div>

                    <div class="mb-3">
                        <label for="model_year" class="form-label fw-bold">Modelo</label>
                        <input type="text" value="<?php echo $model_year;?>" class="form-control" name="model_year" id="model_year" placeholder="Ingrese el modelo del producto" required/>
                        <div class="form-text text-muted">Ejemplo: 2024, XT-500, etc.</div>
                    </div>

                    <div class="mb-3">
                        <label for="price" class="form-label fw-bold">Precio</label>
                        <div class="input-group">
                            <span class="input-group-text">Bs.</span>
                            <input type="number" value="<?php echo $price;?>" class="form-control" name="price" id="price" placeholder="0.00" step="0.01" min="0" required/>
                        </div>
                        <div class="form-text text-muted">Actualice el precio del producto</div>
                    </div>
                </div>

                <!-- Columna Derecha -->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="category_id" class="form-label fw-bold">Categoría</label>
                        <select class="form-select" name="category_id" id="category_id" required>
                            <option value="">Seleccione una categoría</option>
                            <?php foreach($categorias as $categoria) { ?>
                                <option value="<?php echo $categoria['category_id']; ?>" 
                                    <?php echo ($categoria['category_id'] == $category_id) ? 'selected' : ''; ?>>
                                    <?php echo $categoria['category_name']; ?>
                                </option>
                            <?php } ?>
                        </select>
                        <div class="form-text text-muted">Seleccione la categoría del producto</div>
                    </div>

                    <div class="mb-3">
                        <label for="foto" class="form-label fw-bold">Imagen del Producto</label>
                        <?php if(!empty($foto)): ?>
                            <div class="mb-2">
                                <img src="./foto/<?php echo $foto;?>" class="img-thumbnail" alt="Foto del producto" style="max-height: 150px;"/>
                                <div class="form-text text-muted">Imagen actual</div>
                            </div>
                        <?php else: ?>
                            <div class="text-muted mb-2">No hay imagen disponible</div>
                        <?php endif; ?>
                        <input type="file" class="form-control" name="foto" id="foto" accept="image/*"/>
                        <div class="form-text text-muted">Formatos: JPG, PNG.</div>
                    </div>
                </div>
            </div>

            <!-- Botones de acción -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="d-flex gap-2 justify-content-end">
                        <a class="btn btn-outline-secondary" href="index.php" role="button">
                            Cancelar
                        </a>
                        <button type="submit" class="btn btn-success">
                            Actualizar Producto
                        </button>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>

<?php include("../../templates/footer.php"); ?>