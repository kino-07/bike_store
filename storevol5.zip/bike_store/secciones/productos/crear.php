<?php include("../../bd.php");

// Obtener todas las categorías para el select
$sentencia_categorias = $conexion->prepare("SELECT * FROM categories");
$sentencia_categorias->execute();
$categorias = $sentencia_categorias->fetchAll(PDO::FETCH_ASSOC);

if($_POST){
    $product_name=(isset($_POST['product_name'])?$_POST['product_name']:"");
    $foto = (isset($_FILES['foto']['name'])) ? $_FILES['foto']['name'] : "";
    $model_year=(isset($_POST['model_year'])?$_POST['model_year']:"");   
    $price=(isset($_POST['price'])?$_POST['price']:"");
    $category_id=(isset($_POST['category_id'])?$_POST['category_id']:"");  
    
    $sentencia = $conexion->prepare("INSERT INTO products (product_name, foto, model_year, price, category_id)
    VALUES (:product_name, :foto, :model_year, :price, :category_id)");

    $sentencia->bindParam(":product_name",$product_name);
    
    $fecha_=new DateTime();
    $nombreArchivo_imaj=($foto!='')?$fecha_->getTimestamp()."_".$_FILES['foto']['name']:"" ;
    $tmp_imaj = $_FILES['foto']['tmp_name'];
    if ($tmp_imaj!=''){
        move_uploaded_file($tmp_imaj,"./foto/".$nombreArchivo_imaj);
    }

    $sentencia->bindParam(":foto",$nombreArchivo_imaj);
    $sentencia->bindParam(":model_year",$model_year);
    $sentencia->bindParam(":price",$price);
    $sentencia->bindParam(":category_id",$category_id);
    $sentencia->execute();
    $mensaje="registro agregado";
    header("Location: index.php");
}
?>

<?php include("../../templates/header.php"); ?>

<div class="card shadow-sm">
    <div class="card-header bg-primary text-white py-3">
        <h4 class="mb-0">Crear Nuevo Producto</h4>
    </div>
    <div class="card-body p-4">
        <form action="" method="post" enctype="multipart/form-data">
            
            <div class="row">
                <!-- Columna Izquierda -->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="product_name" class="form-label fw-bold">Nombre del Producto</label>
                        <input type="text" class="form-control" name="product_name" id="product_name" placeholder="Ingrese el nombre del producto" required/>
                        <div class="form-text text-muted">Ingrese el nombre completo del producto</div>
                    </div>

                    <div class="mb-3">
                        <label for="model_year" class="form-label fw-bold">Modelo</label>
                        <input type="text" class="form-control" name="model_year" id="model_year" placeholder="Ingrese el modelo del producto" required/>
                        <div class="form-text text-muted">Ejemplo: 2024, XT-500, etc.</div>
                    </div>

                    <div class="mb-3">
                        <label for="price" class="form-label fw-bold">Precio</label>
                        <div class="input-group">
                            <span class="input-group-text">Bs.</span>
                            <input type="number" class="form-control" name="price" id="price" placeholder="0.00" step="0.01" min="0" required/>
                        </div>
                        <div class="form-text text-muted">Ingrese el precio del producto</div>
                    </div>
                </div>

                <!-- Columna Derecha -->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="category_id" class="form-label fw-bold">Categoría</label>
                        <select class="form-select" name="category_id" id="category_id" required>
                            <option value="">Seleccione una categoría</option>
                            <?php foreach($categorias as $categoria) { ?>
                                <option value="<?php echo $categoria['category_id']; ?>">
                                    <?php echo $categoria['category_name']; ?>
                                </option>
                            <?php } ?>
                        </select>
                        <div class="form-text text-muted">Seleccione la categoría del producto</div>
                    </div>

                    <div class="mb-3">
                        <label for="foto" class="form-label fw-bold">Imagen del Producto</label>
                        <input type="file" class="form-control" name="foto" id="foto" accept="image/*"/>
                        <div class="form-text text-muted">Formatos: JPG, PNG.</div>
                    </div>
                </div>
            </div>

            <!-- Botones de acción -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="d-flex gap-2 justify-content-end">
                        <a class="btn btn-outline-secondary" href="index.php" role="button">
                            Cancelar
                        </a>
                        <button type="submit" class="btn btn-success">
                            Agregar Producto
                        </button>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>

<?php include("../../templates/footer.php"); ?>