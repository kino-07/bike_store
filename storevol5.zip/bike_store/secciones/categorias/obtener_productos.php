<?php
/*
include("../../bd.php");

if(isset($_GET['category_id'])) {
    $category_id = $_GET['category_id'];
    
    $sentencia = $conexion->prepare("SELECT * FROM products WHERE category_id = :category_id");
    $sentencia->bindParam(":category_id", $category_id);
    $sentencia->execute();
    $productos = $sentencia->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($productos);
}*/
?>