<?php
include("../../bd.php");

//categories
//category_id
//category_name
//description

//envio de parametros en la url en el metodo get
if (isset($_GET['txtID'])){
    $txtID=(isset($_GET['txtID']))?$_GET['txtID']:"";
    //BUSCAR EL ARCHIVO RELACIONADO CON EL CLIENTE 
    $sentencia=$conexion->prepare("SELECT * FROM categories WHERE category_id=:id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia-> execute();
    $registro_recuperado=$sentencia->fetch(PDO::FETCH_LAZY);//se utiliza el fetch lazy cuando es solo un dato

    //borra los datos del cliente

    $sentencia=$conexion->prepare("DELETE FROM categories WHERE category_id =:id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();
    $mensaje="REGISTRO ELIMINADO";
}

//consulta para traer las categorías
$sentencia = $conexion->prepare("SELECT * FROM categories");
$sentencia->execute();
$lista_categorias = $sentencia->fetchAll(PDO::FETCH_ASSOC);

// Función para obtener productos por categoría
function obtenerProductosPorCategoria($conexion, $category_id) {
    $sentencia = $conexion->prepare("SELECT * FROM products WHERE category_id = :category_id");
    $sentencia->bindParam(":category_id", $category_id);
    $sentencia->execute();
    return $sentencia->fetchAll(PDO::FETCH_ASSOC);
}
?>
<?php
include("../../templates/header.php");
?>

<h2>Lista de Categorías</h2>

<!--bs5-card-bead-fut para agregar lo de abajo-->
<div class="card">
    <div class="card-header">
        <a class="btn btn-outline-primary" href="crear.php" role="button">CREAR NUEVA CATEGORIA</a>
    </div>
    <div class="card-body" >
        <div class="table-responsive-sm">
            <table class="table table-primary"  >
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">CATEGORIA</th>
                        <th scope="col">DESCRIPCION</th>
                        <th scope="col">PRODUCTOS</th>
                        <th>ACCIONES</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($lista_categorias as $registro) { 
                        $productos = obtenerProductosPorCategoria($conexion, $registro['category_id']);
                    ?>
                    <tr class="">
                        <td scope="row"><?php echo $registro['category_id']; ?></td>
                        <td><?php echo $registro['category_name']; ?></td>
                        <td><?php echo $registro['description']; ?></td>
                        <td>
                            <button class="btn btn-outline-info btn-sm" 
                                    type="button" 
                                    data-bs-toggle="collapse" 
                                    data-bs-target="#productos<?php echo $registro['category_id']; ?>" 
                                    aria-expanded="false" 
                                    aria-controls="productos<?php echo $registro['category_id']; ?>">
                                Ver Productos (<?php echo count($productos); ?>)
                            </button>
                        </td>
                        <td>
                            <a class="btn btn-outline-primary" href="editar.php?txtID=<?php echo $registro['category_id']; ?>" role="button">Editar</a>
                        </td>
                        <td>
                            <a class="btn btn-outline-danger" href="index.php?txtID=<?php echo $registro['category_id']; ?>" role="button">Eliminar</a>
                        </td>
                    </tr>
                    <!-- Fila desplegable para productos -->
                    <tr class="collapse" id="productos<?php echo $registro['category_id']; ?>">
                        <td colspan="6">
                            <div class="p-3 bg-light rounded">
                                <h6 class="mb-3">Productos en esta categoría:</h6>
                                <?php if(count($productos) > 0): ?>
                                    <div class="table-responsive">
                                        <table class="table table-sm table-bordered">
                                            <thead class="table-secondary">
                                                <tr>
                                                    <th>ID Producto</th>
                                                    <th>Nombre</th>
                                                    <th>Precio</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach($productos as $producto): ?>
                                                    <tr>
                                                        <td><?php echo $producto['product_id']; ?></td>
                                                        <td><?php echo $producto['product_name']; ?></td>
                                                        <td>Bs.<?php echo number_format($producto['price'], 2); ?></td>   
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php else: ?>
                                    <p class="text-muted mb-0">No hay productos en esta categoría.</p>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
include("../../templates/footer.php");
?>