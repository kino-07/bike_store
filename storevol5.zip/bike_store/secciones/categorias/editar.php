<?php include("../../bd.php");

if (isset($_GET['txtID'])){
    $txtID=(isset($_GET['txtID']))?$_GET['txtID']:"";
    $sentencia = $conexion->prepare("SELECT * FROM categories WHERE category_id = :id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();
    $registro=$sentencia->fetch(PDO::FETCH_LAZY);
    $category_name=$registro["category_name"];
    $description=$registro["description"];
}

if($_POST){
    $category_name=(isset($_POST['category_name'])?$_POST['category_name']:"");
    $description=(isset($_POST['description'])?$_POST['description']:"");
    
    $sentencia = $conexion->prepare("UPDATE categories SET
    category_name= :category_name, description=:description WHERE category_id=:id");

    $sentencia->bindParam(":category_name",$category_name);
    $sentencia->bindParam(":description",$description);
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();

    $mensaje="registro actualizado";
    header("Location: index.php?mensaje=".$mensaje);
}
?>

<?php include("../../templates/header.php"); ?>

<div class="card shadow-sm">
    <div class="card-header bg-primary text-white py-3">
        <h4 class="mb-0">Editar Categoría</h4>
    </div>
    <div class="card-body p-4">
        <form action="" method="post">
            
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="mb-3">
                        <label for="category_id" class="form-label fw-bold">ID de la Categoría</label>
                        <input type="text" value="<?php echo $txtID;?>" class="form-control" readonly name="category_id" id="category_id"/>
                    </div>

                    <div class="mb-4">
                        <label for="category_name" class="form-label fw-bold">Nombre de la Categoría</label>
                        <input type="text" value="<?php echo $category_name;?>" class="form-control" name="category_name" id="category_name" placeholder="Ingrese el nombre de la categoría" required/>
                        <div class="form-text text-muted">Actualice el nombre de la categoría</div>
                    </div>

                    <div class="mb-4">
                        <label for="description" class="form-label fw-bold">Descripción</label>
                        <textarea class="form-control" name="description" id="description" rows="4" placeholder="Actualice la descripción de la categoría" required><?php echo $description;?></textarea>
                        <div class="form-text text-muted">Actualice la descripción detallada de esta categoría</div>
                    </div>
                </div>
            </div>

            <!-- Botones de acción -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="d-flex gap-2 justify-content-center">
                        <a class="btn btn-outline-secondary" href="index.php" role="button">
                            Cancelar
                        </a>
                        <button type="submit" class="btn btn-success">
                            Actualizar Categoría
                        </button>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>

<?php include("../../templates/footer.php"); ?>