<?php include("../../bd.php");

if($_POST){
    $category_name=(isset($_POST['category_name'])?$_POST['category_name']:"");
    $description=(isset($_POST['description'])?$_POST['description']:"");
  
    $sentencia = $conexion->prepare("INSERT INTO categories (category_name, description)
    VALUES (:category_name, :description)");

    $sentencia->bindParam(":category_name",$category_name);
    $sentencia->bindParam(":description",$description);
    $sentencia->execute();
    $mensaje="registro agregado";
    header("Location: index.php");
}
?>

<?php include("../../templates/header.php"); ?>

<div class="card shadow-sm">
    <div class="card-header bg-primary text-white py-3">
        <h4 class="mb-0">Crear Nueva Categoría</h4>
    </div>
    <div class="card-body p-4">
        <form action="" method="post">
            
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="mb-4">
                        <label for="category_name" class="form-label fw-bold">Nombre de la Categoría</label>
                        <input type="text" class="form-control" name="category_name" id="category_name" placeholder="Ingrese el nombre de la categoría" required/>
                        <div class="form-text text-muted">Ingrese un nombre único para la categoría</div>
                    </div>

                    <div class="mb-4">
                        <label for="description" class="form-label fw-bold">Descripción</label>
                        <textarea class="form-control" name="description" id="description" rows="4" placeholder="Agregue una descripción detallada de la categoría" required></textarea>
                        <div class="form-text text-muted">Describa las características y propósito de esta categoría</div>
                    </div>
                </div>
            </div>

            <!-- Botones de acción -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="d-flex gap-2 justify-content-center">
                        <a class="btn btn-outline-secondary" href="index.php" role="button">
                            Cancelar
                        </a>
                        <button type="submit" class="btn btn-success">
                            Agregar Categoría
                        </button>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>

<?php include("../../templates/footer.php"); ?>