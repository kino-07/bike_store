<?php include("../../bd.php");

if (isset($_GET['txtID'])){
    $txtID=(isset($_GET['txtID']))?$_GET['txtID']:"";
    $sentencia = $conexion->prepare("SELECT * FROM usuarios WHERE usuario_id = :id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();
    $registro=$sentencia->fetch(PDO::FETCH_LAZY);
    $usuario=$registro["usuario"];
    $clave=$registro["clave"];
    $email=$registro["email"];
    $role=$registro["role"];
}

if($_POST){
    $usuario=(isset($_POST['usuario'])?$_POST['usuario']:"");
    $clave=(isset($_POST['clave'])?$_POST['clave']:"");   
    $email=(isset($_POST['email'])?$_POST['email']:"");
    $role=(isset($_POST['role'])?$_POST['role']:"");  

    $sentencia = $conexion->prepare("UPDATE usuarios SET
    usuario= :usuario,
    clave=:clave,
    email=:email,
    role=:role WHERE usuario_id=:id");

    $sentencia->bindParam(":usuario",$usuario);
    $sentencia->bindParam(":clave",$clave);
    $sentencia->bindParam(":email",$email);
    $sentencia->bindParam(":role",$role);
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();

    $mensaje="registro actualizado";
    header("Location: index.php?mensaje=".$mensaje);
}
?>

<?php include("../../templates/header.php"); ?>

<div class="card shadow-sm">
    <div class="card-header bg-primary text-white py-3">
        <h4 class="mb-0">Editar Usuario</h4>
    </div>
    <div class="card-body p-4">
        <form action="" method="post">
            
            <div class="row">
                <!-- Columna Izquierda -->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="usuario_id" class="form-label fw-bold">ID del Usuario</label>
                        <input type="text" value="<?php echo $txtID;?>" class="form-control" readonly name="usuario_id" id="usuario_id"/>
                    </div>

                    <div class="mb-3">
                        <label for="usuario" class="form-label fw-bold">Usuario</label>
                        <input type="text" value="<?php echo $usuario;?>" class="form-control" name="usuario" id="usuario" placeholder="Ingrese el nombre de usuario" required/>
                        <div class="form-text text-muted">Nombre de usuario para acceder al sistema</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="clave" class="form-label fw-bold">Contraseña</label>
                        <input type="password" value="<?php echo $clave;?>" class="form-control" name="clave" id="clave" placeholder="Ingrese la contraseña" required/>
                        <div class="form-text text-muted">La contraseña debe ser segura</div>
                    </div>
                </div>

                <!-- Columna Derecha -->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="email" class="form-label fw-bold">Correo Electrónico</label>
                        <input type="email" value="<?php echo $email;?>" class="form-control" name="email" id="email" placeholder="correo@ejemplo.com" required/>
                        <div class="form-text text-muted">Ingrese un correo electrónico válido</div>
                    </div>

                    <div class="mb-3">
                        <label for="role" class="form-label fw-bold">Rol de Usuario</label>
                        <select class="form-select" name="role" id="role" required>
                            <option value="">Seleccione un rol</option>
                            <option value="admin" <?php echo ($role == 'admin') ? 'selected' : ''; ?>>Administrador</option>
                            <option value="user" <?php echo ($role == 'user') ? 'selected' : ''; ?>>Usuario</option>
                            <option value="viewer" <?php echo ($role == 'viewer') ? 'selected' : ''; ?>>Visualizador</option>
                        </select>
                        <div class="form-text text-muted">Seleccione el nivel de acceso del usuario</div>
                    </div>
                </div>
            </div>

            <!-- Botones de acción -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="d-flex gap-2 justify-content-end">
                        <a class="btn btn-outline-secondary" href="index.php" role="button">
                            Cancelar
                        </a>
                        <button type="submit" class="btn btn-success">
                            Actualizar Usuario
                        </button>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>

<?php include("../../templates/footer.php"); ?>