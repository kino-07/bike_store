<?php include("../../bd.php");
//usuarios
//usuario_id
//usuario
//clave
//email
//role
if($_POST){
    $usuario=(isset($_POST['usuario'])?$_POST['usuario']:"");
    $clave=(isset($_POST['clave'])?$_POST['clave']:"");   
    $email=(isset($_POST['email'])?$_POST['email']:"");
    $role=(isset($_POST['role'])?$_POST['role']:"");  

    //preparamos la insercion de los datos
    $sentencia = $conexion->prepare("INSERT INTO usuarios (usuario, clave, email, role)
    VALUES (:usuario, :clave, :email, :role)");

    $sentencia->bindParam(":usuario",$usuario);
    $sentencia->bindParam(":clave",$clave);
    $sentencia->bindParam(":email",$email);
    $sentencia->bindParam(":role",$role);
    $sentencia->execute();
    $mensaje="registro agregado";
    header("Location: index.php");
}
?>

<?php include("../../templates/header.php"); ?>

<div class="card shadow-sm">
    <div class="card-header bg-primary text-white py-3">
        <h4 class="mb-0">Crear Nuevo Usuario</h4>
    </div>
    <div class="card-body p-4">
        <form action="" method="post">
            
            <div class="row">
                <!-- Columna Izquierda -->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="usuario" class="form-label fw-bold">Usuario</label>
                        <input type="text" class="form-control" name="usuario" id="usuario" placeholder="Ingrese el nombre de usuario" required/>
                        <div class="form-text text-muted">Ingrese un nombre de usuario único</div>
                    </div>

                    <div class="mb-3">
                        <label for="clave" class="form-label fw-bold">Contraseña</label>
                        <input type="password" class="form-control" name="clave" id="clave" placeholder="Ingrese la contraseña" required/>
                        <div class="form-text text-muted">La contraseña debe ser segura</div>
                    </div>
                </div>

                <!-- Columna Derecha -->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="email" class="form-label fw-bold">Correo Electrónico</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="correo@ejemplo.com" required/>
                        <div class="form-text text-muted">Ingrese un correo electrónico válido</div>
                    </div>

                    <div class="mb-3">
                        <label for="role" class="form-label fw-bold">Rol de Usuario</label>
                        <select class="form-select" name="role" id="role" required>
                            <option value="">Seleccione un rol</option>
                            <option value="admin">Administrador</option>
                            <option value="user">Usuario</option>
                            <option value="viewer">Visualizador</option>
                        </select>
                        <div class="form-text text-muted">Seleccione el nivel de acceso del usuario</div>
                    </div>
                </div>
            </div>

            <!-- Botones de acción -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="d-flex gap-2 justify-content-end">
                        <a class="btn btn-outline-secondary" href="index.php" role="button">
                            Cancelar
                        </a>
                        <button type="submit" class="btn btn-success">
                            Agregar Usuario
                        </button>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>

<?php include("../../templates/footer.php"); ?>