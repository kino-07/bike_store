<?php include("../../bd.php");
if (isset($_GET['txtID'])){
    $txtID=(isset($_GET['txtID']))?$_GET['txtID']:"";
    $sentencia = $conexion->prepare("UPDATE ordes SET estado='ANULADO' WHERE order_id = :id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();
    $mensaje="REGISTRO ELIMINADO";


}
//consulta para pedidos clientes como unico registro
$sentencia = $conexion-> prepare("SELECT *,
(SELECT CONCAT(first_name,' ',last_name) AS nombre_completo FROM customers WHERE customers_id=ordes.customer_id limit 1) AS cliente, 
(SELECT usuario FROM usuarios WHERE usuarios_id=ordes.usuario_id limit 1) AS usuario FROM ordes");
$sentencia->execute();
$lista_pedidos=$sentencia->fetchAll(PDO::FETCH_ASSOC);
//print_r ($lista_clientes);

?>

<?php include("../../templates/header.php"); ?>
<h3>
    <div class="card">
        <div class="card-header">Header</div>
        <div class="card-body">
            <h4 class="card-title">Title</h4>
            <p class="card-text">Text</p>
        </div>
        <div class="card-footer text-muted">Footer</div>
    </div>
    
</h3>