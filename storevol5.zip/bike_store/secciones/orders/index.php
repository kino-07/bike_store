<?php include("../../bd.php");

if (isset($_GET['txtID'])){
    $txtID = (isset($_GET['txtID'])) ? $_GET['txtID'] : "";
    $sentencia = $conexion->prepare("UPDATE orders SET estado = 'ANULADO' WHERE order_id = :id");
    $sentencia->bindParam(":id", $txtID);
    $sentencia->execute();
    $mensaje = "PEDIDO ANULADO";
}

// Consulta corregida para pedidos
$sentencia = $conexion->prepare("SELECT *,
    (SELECT CONCAT(first_name, ' ', last_name) AS nombre_completo FROM customers 
     WHERE customer_id = customer_id LIMIT 1) AS cliente,
    (SELECT usuario FROM usuarios WHERE usuario_id = usuario_id LIMIT 1) AS usuario FROM orders");

$sentencia->execute();
$lista_pedidos = $sentencia->fetchAll(PDO::FETCH_ASSOC);
?>


<?php include("../../templates/header.php"); ?>
<h3>Pedidos</h3>
<div class="card">
    <div class="card-header">
        <a name="" id="" class="btn btn-outline-primary" href="crear.php" role="button"> Nuevo</a></div>
    <div class="card-body">
        <div class="table-responsive-sm">
            <table class="table table-primary" id="Table_id">
                <thead >
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Fecha</th>
                        <th scope="col">Cliente</th>
                        <th scope="col">estado</th>
                        <th scope="col">Usuario</th>
                        <th scope="col">Monto Total</th>
                        <th scope="col">accion</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($lista_pedidos as $registro) {?>
                    <tr class="">
                        <td scope="row"> <?php echo $registro ['order_id'] ?> </td>
                        <td> <?php echo $registro ['order_date']; ?> </td>
                        <td> <?php echo $registro ['cliente']; ?> </td>
                        <td> <?php echo $registro ['estado']; ?> </td>
                        <td> <?php echo $registro ['usuario']; ?> </td>
                        <td> <?php echo $registro ['total_amount']; ?> </td>
                        <td>
                            <a name="" id="" class="btn btn-outline-primary" href="detalle.php?txtID=<?php echo $registro['order_id']; ?>" role="button">detalle</a>
                            
                            <a name="" id="" class="btn btn-outline-danger" href="index.php?txtID=<?php echo $registro['order_id']; ?>" role="button">Anular</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
                <tfoot>
                    
                </tfoot>
            </table>
        </div>
        
    </div>
    <div class="card-footer text-muted">Footer</div>
</div>
