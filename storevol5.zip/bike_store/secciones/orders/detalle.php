<?php
include("../../bd.php");

if (isset($_GET['txtID'])){
    $txtID = (isset($_GET['txtID'])) ? $_GET['txtID'] : "";

    //CONUSLTA PARA PEDIDOS CLIENTES MOSTRANDO COMO UNICO REGIST
    $sentencia = $conexion->prepare("SELECT *,
    (SELECT product_name FROM products WHERE product_id = order_items.product_id limit 1) AS producto
    FROM order_items WHERE order_id = :txtID");
    $sentencia->bindParam(":txtID", $txtID);
    $lista_detalle_pedidos = $sentencia->fetchAll(PDO::FETCH_ASSOC);

}
?>
<?php include("../../templates/header.php"); ?>
<h3>Detalles del pedido <?php echo $txtID ?></h3>
<div class="card">
    <div class="card-header">
        <a name="" id="" class="btn btn-outline-primary" href="crear.php" role="button"> Nuevo</a></div>
    <div class="card-body">
        <div class="table-responsive-sm">
            <table class="table table-primary" >
                <thead >
                    <tr>
                        <th scope="col">Item</th>
                        <th scope="col">producto</th>
                        <th scope="col">cantidad</th>
                        <th scope="col">precio</th>
                        <th scope="col">descuento</th>
                        <th scope="col">subtotal</th>
                        <th scope="col">accion</th>

                    </tr>
                </thead>
                <tbody>
                    <?php foreach($lista_detalle_pedidos as $registro) { $i=1; ?>
                    <tr class="">
                        <td scope="row"> <?php echo $i; ?> </td>
                        <td> <?php echo $registro ['producto']; ?> </td>
                        <td> <?php echo $registro ['quantity']; ?> </td>
                        <td> <?php echo $registro ['price']; ?> </td>
                        <td> <?php echo $registro ['discount']; ?> </td>
                        <td> <?php echo ($registro ['quantity'] * $registro ['price'])-( $registro ['total_amount']*100); ?> </td>
                        <td>
                            <a name="" id="" class="btn btn-outline-primary" href="detalle.php?txtID=<?php echo $registro['order_id']; ?>" role="button">detalle</a>
                            
                            <a name="" id="" class="btn btn-outline-danger" href="index.php?txtID=<?php echo $registro['order_id']; ?>" role="button">Anular</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
                <tfoot>
                    
                </tfoot>
            </table>
        </div>
        
    </div>
    <div class="card-footer text-muted">Footer</div>
</div>
