<?php include("../../bd.php");
if($_POST){
    $first_name=(isset($_POST['first_name'])?$_POST['first_name']:"");
    $last_name=(isset($_POST['last_name'])?$_POST['last_name']:"");
    $imagen = (isset($_FILES['imagen']['name'])) ? $_FILES['imagen']['name'] : "";
    $phone=(isset($_POST['phone'])?$_POST['phone']:"");   
    $email=(isset($_POST['email'])?$_POST['email']:"");
    $street=(isset($_POST['street'])?$_POST['street']:"");  
    $city=(isset($_POST['city'])?$_POST['city']:""); 
    $state=(isset($_POST['state'])?$_POST['state']:"");

    $sentencia = $conexion->prepare("INSERT INTO customers (first_name, last_name, imagen, phone, email, street, city, state)
    VALUES (:first_name, :last_name, :imagen, :phone, :email, :street, :city, :state)");

    $sentencia->bindParam(":first_name",$first_name);
    $sentencia->bindParam(":last_name",$last_name);
    
    $fecha_=new DateTime();
    $nombreArchivo_foto=($imagen!='')?$fecha_->getTimestamp()."_".$_FILES['imagen']['name']:"" ;
    $tmp_foto = $_FILES['imagen']['tmp_name'];
    if ($tmp_foto!=''){
        move_uploaded_file($tmp_foto,"./imagen/".$nombreArchivo_foto);
    }

    $sentencia->bindParam(":imagen",$nombreArchivo_foto);
    $sentencia->bindParam(":phone",$phone);
    $sentencia->bindParam(":email",$email);
    $sentencia->bindParam(":street",$street);
    $sentencia->bindParam(":city",$city);
    $sentencia->bindParam(":state",$state);
    $sentencia->execute();
    $mensaje="registro agregado";
    header("Location: index.php");
}
?>

<?php include("../../templates/header.php"); ?>

<div class="card shadow-sm">
    <div class="card-header bg-primary text-white py-3">
        <h4 class="mb-0">Crear Nuevo Cliente</h4>
    </div>
    <div class="card-body p-4">
        <form action="" method="post" enctype="multipart/form-data">
            
            <div class="row">
                <!-- Columna Izquierda - Información Personal -->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="first_name" class="form-label fw-bold">Nombres</label>
                        <input type="text" class="form-control" name="first_name" id="first_name" placeholder="Ingrese los nombres del cliente" required/>
                    </div>
                    
                    <div class="mb-3">
                        <label for="last_name" class="form-label fw-bold">Apellidos</label>
                        <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Ingrese los apellidos del cliente" required/>
                    </div>

                    <div class="mb-3">
                        <label for="phone" class="form-label fw-bold">Teléfono</label>
                        <input type="text" class="form-control" name="phone" id="phone" placeholder="Ingrese el número telefónico" required/>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label fw-bold">Correo Electrónico</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="correo@ejemplo.com" required/>
                    </div>
                </div>

                <!-- Columna Derecha - Dirección y Foto -->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="street" class="form-label fw-bold">Dirección</label>
                        <input type="text" class="form-control" name="street" id="street" placeholder="Ingrese la dirección completa" required/>
                    </div>

                    <div class="mb-3">
                        <label for="city" class="form-label fw-bold">Ciudad</label>
                        <input type="text" class="form-control" name="city" id="city" placeholder="Ingrese la ciudad" required/>
                    </div>

                    <div class="mb-3">
                        <label for="state" class="form-label fw-bold">Departamento/Estado</label>
                        <input type="text" class="form-control" name="state" id="state" placeholder="Ingrese el departamento o estado" required/>
                    </div>

                    <div class="mb-3">
                        <label for="imagen" class="form-label fw-bold">Foto del Cliente</label>
                        <input type="file" class="form-control" name="imagen" id="imagen" accept="image/*"/>
                        <div class="form-text text-muted">Formatos aceptados: JPG, PNG, GIF. Tamaño máximo: 2MB</div>
                    </div>
                </div>
            </div>

            <!-- Botones de acción -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="d-flex gap-2 justify-content-end">
                        <a class="btn btn-outline-secondary" href="index.php" role="button">
                            Cancelar
                        </a>
                        <button type="submit" class="btn btn-success">
                            Agregar Registro
                        </button>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>

<?php include("../../templates/footer.php"); ?>