<?php
include("../../bd.php");
//envio de parametros en la url en el metodo get
if (isset($_GET['txtID'])){
    $txtID=(isset($_GET['txtID']))?$_GET['txtID']:"";
    //BUSCAR EL ARCHIVO RELACIONADO CON EL CLIENTE 
    $sentencia=$conexion->prepare("SELECT imagen FROM customers WHERE customer_id=:id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia-> execute();
    $registro_recuperado=$sentencia->fetch(PDO::FETCH_LAZY);//se utiliza el fetch lazy cuando es solo un dato

    // buscar el arcgibo y eliminar

    if(isset($registro_recuperado['imagen']) && $registro_recuperado['imagen']!=""){
        if(file_exists("./imagen/".$registro_recuperado['imagen'])){
            unlink("./imagen/".$registro_recuperado['imagen']);
        }
    }


    //borra los datos del cliente

    $sentencia=$conexion->prepare("DELETE FROM customers WHERE customer_id =:id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();
    $mensaje="REGISTRO ELIMINADO";
}

//consulta paar traer los clientes y mostrar como unico regisro 
$sentencia = $conexion-> prepare("SELECT * FROM customers"); //el que idce cosytumer el para la tabla asi como usuario asia si 
$sentencia -> execute();
$lista_clientes =  $sentencia-> fetchAll( PDO :: FETCH_ASSOC);
//print_r('$lista_clientes');

?>
<?php
include("../../templates/header.php");
?>



<h2>Lista de Clientes</h2>

<!--bs5-card-bead-fut para agregar lo de abajo-->
<div class="card">
    <div class="card-header"><a class="btn btn-outline-primary" href="crear.php" role="button">Nuevo Cliente</a></div>
    <div class="card-body">
        <div
            class="table-responsive-sm"
        >
            <table
                class="table table-primary " id="Table_id">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">NOMBRES Y APELLIDOS</th>
                        <th scope="col">FOTO</th>
                        <th scope="col">TELEFONO</th>
                        <th scope="col">CORREO</th>
                        <th scope="col">DIRECCION</th>
                        <th scope="col">CIUDAD</th>
                        <th scope="col">DEPARTAMENTO</th>
                        <th scope="col">ACCIONES</th>
                        <th></th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($lista_clientes as $registro) {?>
                    <tr class="">
                        <td scope="row"> <?php echo $registro ['customer_id'] ?> </td>
                        <td>
                            <?php echo $registro ['first_name']; ?>
                            <?php echo $registro ['last_name']; ?>
                        </td>
                        <td><img width="100" src="./imagen//<?php echo $registro ['imagen'];?>"
                        class="img-fluid rounded" alt="foto del cliente" /> </td>
                        <td><?php echo $registro ['phone']; ?></td>
                        <td><?php echo $registro ['email']; ?></td>
                        <td><?php echo $registro ['street']; ?></td>
                        <td><?php echo $registro ['city']; ?></td>
                        <td><?php echo $registro ['state']; ?></td>
                        <td> <a class="btn btn-outline-primary" href="editar.php?txtID=<?php echo $registro ['customer_id']; ?>"role = "button">Editar </a></td>
                        <td> <a class="btn btn-outline-danger" href="javascript:borrar(<?php echo $registro ['customer_id']; ?>)"role = "button">Eliminar </a></td>
                    </tr>
                    <?php }?>
                </tbody>
            </table>
        </div>
        

    </div>

<?php
include("../../templates/footer.php");
?>



