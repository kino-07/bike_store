<?php include("../../bd.php");
if (isset($_GET['txtID'])){
    $txtID=(isset($_GET['txtID']))?$_GET['txtID']:"";
    $sentencia = $conexion->prepare("SELECT * FROM customers WHERE customer_id = :id");
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();
    $registro=$sentencia->fetch(PDO::FETCH_LAZY);
    $first_name=$registro["first_name"];
    $last_name=$registro["last_name"];
    $imagen=$registro["imagen"];
    $phone=$registro["phone"];
    $email=$registro["email"];
    $street=$registro["street"];
    $city=$registro["city"];
    $state=$registro["state"];
}

if($_POST){
    $first_name=(isset($_POST['first_name'])?$_POST['first_name']:"");
    $last_name=(isset($_POST['last_name'])?$_POST['last_name']:"");
    $phone=(isset($_POST['phone'])?$_POST['phone']:"");   
    $email=(isset($_POST['email'])?$_POST['email']:"");
    $street=(isset($_POST['street'])?$_POST['street']:"");  
    $city=(isset($_POST['city'])?$_POST['city']:""); 
    $state=(isset($_POST['state'])?$_POST['state']:"");

    $sentencia = $conexion->prepare("UPDATE customers SET
    first_name= :first_name,
    last_name=:last_name,
    imagen=:imagen,
    phone= :phone,
    email=:email,
    street=:street,
    city=:city,
     state=:state WHERE customer_id=:id");

    $sentencia->bindParam(":first_name",$first_name);
    $sentencia->bindParam(":last_name",$last_name);
    $sentencia->bindParam(":imagen",$nombreArchivo_foto);
    $sentencia->bindParam(":phone",$phone);
    $sentencia->bindParam(":email",$email);
    $sentencia->bindParam(":street",$street);
    $sentencia->bindParam(":city",$city);
    $sentencia->bindParam(":state",$state);
    $sentencia->bindParam(":id",$txtID);
    $sentencia->execute();

    $imagen = (isset($_FILES['imagen']['name'])) ? $_FILES['imagen']['name'] : "";

    $fecha_=new DateTime();
    $nombreArchivo_foto=($imagen!='')?$fecha_->getTimestamp()."_".$_FILES['imagen']['name']:"" ;
    $tmp_foto = $_FILES['imagen']['tmp_name'];
    if ($tmp_foto!=''){
        move_uploaded_file($tmp_foto,"./imagen/".$nombreArchivo_foto);
        $sentencia=$conexion->prepare("SELECT imagen FROM customers WHERE customer_id=:id");
        $sentencia->bindParam(":id",$txtID);
        $sentencia->execute();
        $registro_recuperado=$sentencia->fetch(PDO::FETCH_LAZY);

        if(isset($registro_recuperado['imagen'])&&$registro_recuperado['imagen']!=""){
            if (file_exists("./imagen/".$registro_recuperado['imagen'])){
                unlink("./imagen/".$registro_recuperado['imagen']);
            }
        }
        $sentencia = $conexion->prepare("UPDATE customers SET imagen=:imagen WHERE customer_id=:id");
        $sentencia->bindParam(":imagen",$nombreArchivo_foto);
        $sentencia->bindParam(":id",$txtID);
        $sentencia->execute();
    }

    $mensaje="registro actualizado";
    header("Location: index.php?mensaje",$mensaje);
}
?>

<?php include("../../templates/header.php"); ?>

<div class="card shadow-sm">
    <div class="card-header bg-primary text-white py-3">
        <h4 class="mb-0">Editar Cliente</h4>
    </div>
    <div class="card-body p-4">
        <form action="" method="post" enctype="multipart/form-data">
            
            <div class="row">
                <!-- Columna Izquierda - Información Personal -->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="customer_id" class="form-label fw-bold">ID del Cliente</label>
                        <input type="text" value="<?php echo $txtID;?>" class="form-control" readonly name="customer_id" id="customer_id"/>
                    </div>

                    <div class="mb-3">
                        <label for="first_name" class="form-label fw-bold">Nombres</label>
                        <input type="text" value="<?php echo $first_name;?>" class="form-control" name="first_name" id="first_name" placeholder="Ingrese los nombres del cliente"/>
                    </div>
                    
                    <div class="mb-3">
                        <label for="last_name" class="form-label fw-bold">Apellidos</label>
                        <input type="text" value="<?php echo $last_name;?>" class="form-control" name="last_name" id="last_name" placeholder="Ingrese los apellidos del cliente"/>
                    </div>

                    <div class="mb-3">
                        <label for="phone" class="form-label fw-bold">Teléfono</label>
                        <input type="text" value="<?php echo $phone;?>" class="form-control" name="phone" id="phone" placeholder="Ingrese el número telefónico"/>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label fw-bold">Correo Electrónico</label>
                        <input type="email" value="<?php echo $email;?>" class="form-control" name="email" id="email" placeholder="correo@ejemplo.com"/>
                    </div>
                </div>

                <!-- Columna Derecha - Dirección y Foto -->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="street" class="form-label fw-bold">Dirección</label>
                        <input type="text" value="<?php echo $street;?>" class="form-control" name="street" id="street" placeholder="Ingrese la dirección completa"/>
                    </div>

                    <div class="mb-3">
                        <label for="city" class="form-label fw-bold">Ciudad</label>
                        <input type="text" value="<?php echo $city;?>" class="form-control" name="city" id="city" placeholder="Ingrese la ciudad"/>
                    </div>

                    <div class="mb-3">
                        <label for="state" class="form-label fw-bold">Departamento/Estado</label>
                        <input type="text" value="<?php echo $state;?>" class="form-control" name="state" id="state" placeholder="Ingrese el departamento o estado"/>
                    </div>

                    <div class="mb-3">
                        <label for="imagen" class="form-label fw-bold">Foto del Cliente</label>
                        <div class="mb-2">
                            <?php if($imagen): ?>
                                <img src="./imagen/<?php echo $imagen;?>" class="img-thumbnail" alt="Foto del cliente" style="max-height: 150px;"/>
                            <?php else: ?>
                                <div class="text-muted">No hay imagen disponible</div>
                            <?php endif; ?>
                        </div>
                        <input type="file" class="form-control" name="imagen" id="imagen" accept="image/*"/>
                        <div class="form-text text-muted">Formatos aceptados: JPG, PNG</div>
                    </div>
                </div>
            </div>

            <!-- Botones de acción -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="d-flex gap-2 justify-content-end">
                        <a class="btn btn-outline-secondary" href="index.php" role="button">
                            <i class="bi bi-x-circle"></i> Cancelar
                        </a>
                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-circle"></i> Actualizar Registro
                        </button>
                    </div>
                </div>
            </div>

        </form>
    </div>
</div>

<?php include("../../templates/footer.php"); ?>