<?php
$url_base="http://localhost/bike_store/";
?>
<!doctype html>
<html lang="en">
    <head>
        <title>CLINICA VETERINARIA</title>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta
            name="viewport"
            content="width=device-width, initial-scale=1, shrink-to-fit=no"
        />

        <!-- Bootstrap CSS v5.2.1 -->
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
            crossorigin="anonymous"
        />
        <!-- esto es jqery -->   
<script
  src="https://code.jquery.com/jquery-3.7.1.min.js"
  integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="
  crossorigin="anonymous"></script>

        <!-- datatables css v2.3.4 -->

        <link rel="stylesheet" href="https://cdn.datatables.net/2.3.4/css/dataTables.dataTables.css" />
  
        <script src="https://cdn.datatables.net/2.3.4/js/dataTables.js"></script>

         <!-- esto es el sweetalert2 v11-->
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        
        <style>
            .nav-item .nav-link {
                transition: all 0.3s ease;
                border-radius: 5px;
                margin: 2px;
            }
            .nav-item .nav-link:hover {
                background-color: #6c757d;
                color: white !important;
                transform: translateY(-2px);
            }
            .nav-item .nav-link.active {
                background-color: #495057;
                color: white !important;
                font-weight: bold;
            }
            .nav-item .nav-link:focus {
                background-color: #17a2b8;
                color: white !important;
            }
        </style>
    </head>

    <body class="bg-light">
        <header>
            <nav class="navbar navbar-expand navbar-light bg-light shadow-sm">
                <ul class="nav navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $url_base;?>index.php" aria-current="page"
                            >Clinica Veterinaria</a
                        >
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $url_base;?>secciones/clientes">Clientes</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $url_base;?>secciones/usuarios">Usuario</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $url_base;?>secciones/productos">Productos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $url_base;?>secciones/categorias">Categorias</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $url_base;?>secciones/orders">Pedidos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $url_base;?>cerrar.php">Cerrar Sesion</a>
                    </li>
                </ul>
             </nav>
             <br>
        </header>

        <main class="container bg-white rounded shadow-sm p-4">
        <!-- Si hubo envio de mensaje entonces ponemos el mensaje-->
<?php if(isset($_GET['mensaje'])) { ?>
<script>
    Swal.fire({icon:"success", title:"<?php echo $_GET['mensaje']; ?>"});
</script>
<?php } ?>