</main>
        <footer class="bg-dark text-white py-4">
            <div class="container text-center">
                <h3 class="mb-3">Clinica Veterinaria</h3>
                <p class="mb-0"><strong>Copyright 2025 clinica Vet -- Todos los derechos Reservados.</strong></p>
            </div>
        </footer>
        <!-- Bootstrap JavaScript Libraries -->
        <script
            src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
            integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
            crossorigin="anonymous"
        ></script>
        <!-- buscador de tabla -->
        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
            integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
            crossorigin="anonymous"
        ></script>

        <script>
            $(document).ready(function(){
                $("#Table_id").DataTable({
                    "pageLength":3, 
                    lengthMenu:[
                    [5,10,25,50],
                    [5,10,25,50]
                    ],
                    "language":{
                    "url":"https://cdn.datatables.net/plug-ins/2.3.4/i18n/es-ES.json"}
                })
            });
        </script>

               <!-- para eliminar interactivamnete -->
      <script>
          /*const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
          confirmButton: "btn btn-success",
          cancelButton: "btn btn-danger"
        },
        buttonsStyling: false
      });*/
     // swalWithBootstrapButtons.fire({
        function borrar(id){
            Swal.fire({
                title: "¿Estás seguro?",
                text: "¡No podrás revertir esto!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Sí, ¡elimínalo!",
            }).then((result) => {
                if (result.isConfirmed) {
                  Swal.fire({
                    title: "¡Eliminado!",
                    text: "El registro ha sido eliminado.",
                    icon: "success",
                  });
                  window.location= "index.php?txtID=" + id;
   
                }
            });
        }
      </script>
    </body>
</html>